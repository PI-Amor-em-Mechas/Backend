package br.com.amorEmMechas_Formulario.api.para.formulario.integration.twilio;

public interface WhatsAppService {


    void enviarMensagem(String numero, String mensagem);

}
