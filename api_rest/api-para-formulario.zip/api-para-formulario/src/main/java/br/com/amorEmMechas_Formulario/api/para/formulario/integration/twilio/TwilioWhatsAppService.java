package br.com.amorEmMechas_Formulario.api.para.formulario.integration.twilio;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.twilio.Twilio;

@Service
public class TwilioWhatsAppService implements WhatsAppService{

    @Value("${twilio.sid}")
    private String sid;

    @Value("${twilio.token}")
    private String token;


    @PostConstruct
    public void init(){
        Twilio.init(sid, token);
    }


    @Override
    public void enviarMensagem(String numero, String mensagem) {

        Message.creator(
                new PhoneNumber("whatsapp:" + numero),
                new PhoneNumber("whatsapp:+14155238886"),
                mensagem
        ).create();
    }
}
